class Main
{
	public static void main(String[] args) {
		System.out.println("jai gla ");
		System.out.println("yug gupta ");
		System.out.println("2215002058");		
	}
}
