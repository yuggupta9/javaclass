import java.util.Scanner;

class Main{
	
	 static double area_of_cir(double r){
	 float pi= 3.14f;
     double area= pi*r*r;
     return area;
	}
	void area_of_rect(int x, int y) {
	System.out.println(x*y);
   }
	
	public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
		Main m = new Main();
         System.out.println("Enter the radius");
         double R = s.nextDouble();
         System.out.println("the area of circle is");
         System.out.println(m.area_of_cir(R));
         System.out.println("Enter the length and breadth");
         int L= s.nextInt();
         int B= s.nextInt();
         System.out.println("the area of rectangle is ");
         m.area_of_rect(L,B);
	}

}