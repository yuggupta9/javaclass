//6.    Write a Java   program to check whether a year is leap year or not.
import java.util.*;
class Main
{
  public static void main (String arg[])
  {
    Scanner sc = new Scanner (System.in);
      System.out.println ("enter the year");
    int year = sc.nextInt ();
    if ((year % 4 == 0 && year % 100 != 0) || (year % 400==0))
      {
	System.out.println ("the " + year + " is leap year ");
      }
    else
      {
	System.out.println ("the " + year + " is not leap year ");
      }
  }
}
