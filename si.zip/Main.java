class Main
{
	public static void main(String[] args) {
	    int p,r,t;
	    double si;
	    p=1;
	    r=2;
	    t=3;
	    float a=100;
	    si=(p*r*t)/a;
		System.out.println(si);
	}
}
