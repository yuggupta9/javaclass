//3.	Write a java program to concatenate two strings.
import java.util.*;
class Main {
    public static void main (String arg[]){
        Scanner sc = new Scanner (System.in);
        String str1 = sc.nextLine();
        String str2 = sc.nextLine();
        System.out.println(str1 + str2);
    }
}