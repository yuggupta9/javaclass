//1.    Write a  Javaprogram to find maximum between two numbers.
import java.util.*;
class Main
{
  public static void main (String arg[])
  {
    Scanner sc = new Scanner (System.in);
      System.out.println ("enter the numbers");
    int num1 = sc.nextInt ();
    int num2 = sc.nextInt ();
    if (num1 > num2)
      {
	System.out.print ("the " + num1 + " is greater");
      }
    else
      {
	System.out.print ("the " + num2 + " is greater");
      }
  }
}
