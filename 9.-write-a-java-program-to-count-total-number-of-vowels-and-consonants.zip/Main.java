//9.	Write a java program to count total number of vowels and consonants 
import java.util.*;
class Main {
    public static void main (String arg[]){
        Scanner sc = new Scanner (System.in);
        String str = sc.next();
        int consonants=0;
        int vowels=0;
        for(int i=0; i<str.length(); i++){
            
            if (str.charAt(i)=='a' || str.charAt(i)=='e' || str.charAt(i)=='i' || str.charAt(i)=='o' || str.charAt(i)=='u' || str.charAt(i)=='A' || str.charAt(i)=='E' || str.charAt(i)=='I' || str.charAt(i)=='O' || str.charAt(i)=='U' ){
                vowels++;
            }else {
                consonants++;
            }
        }
        System.out.println("total no. of vowels " +vowels)
        System.out.println("total no. of consonants " +consonants)

    }
}