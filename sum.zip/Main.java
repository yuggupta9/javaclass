class Main
{
    public static void main(String[] arg){
        int a,b,c;
        a=5;
        b=5;
        c=a+b;
        System.out.println(c);
    } 
}