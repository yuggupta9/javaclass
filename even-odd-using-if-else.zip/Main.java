//5.    Write a   Java   program to check whether a number is even or odd.
import java.util.*;
class Main
{
  public static void main (String arg[])
  {
    Scanner sc = new Scanner (System.in);
      System.out.println ("enter the numbers");
    int num = sc.nextInt ();
    if (num % 2 == 0)
      {
	System.out.println ("the " + num + " is even");
      }
    else
      {
	System.out.println ("the " + num + " is odd");
      }
  }
}
