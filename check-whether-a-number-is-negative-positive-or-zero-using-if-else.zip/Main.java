//3.    Write a    Java program to check whether a number is negative, positive or zero.
import java.util.*;
class Main
{
  public static void main (String arg[])
  {
    Scanner sc = new Scanner (System.in);
      System.out.println ("enter the numbers");
    int num = sc.nextInt ();
    if (num > 0)
      {
	System.out.println ("the number " + num + " is positive");
      }
    else if (num < 0)
      {
	System.out.println ("the number " + num + " is negative");
      }
    else
      {
	System.out.println ("the number " + num + " is zero");
      }
  }
}
