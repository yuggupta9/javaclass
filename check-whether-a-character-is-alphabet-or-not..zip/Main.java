//7.    Write a Java program to check whether a character is alphabet or not.
import java.util.*;
class Main
{
  public static void main (String arg[])
  {
    Scanner sc = new Scanner (System.in);
      System.out.println ("enter the character");
    char a = sc.next ().charAt (0);
    if ((a >= 'a' && a <= 'z') || (a >= 'A' && a <= 'Z'))
      {
	System.out.println ("this is not an alphabet");
      }
    else
      {
	System.out.println ("this is an alphabet");
      }
  }
}
