//8.	Write a java program to find total number of alphabets, digits or special character in a string.
import java.util.*;
class Main {
    public static void main (String arg[]){
        Scanner sc = new Scanner(System.in);
        String str = sc.next();
        int k = str.length();
        System.out.println(k);
    }
}