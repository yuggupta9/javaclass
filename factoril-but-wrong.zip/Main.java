import java.util.*;
class Main{
public static void main (String arg[]){
    Scanner sc = new Scanner(System.in);
    int n = sc.nextInt();
    int fact = 0;
    for (int i = 1 ; i<=n ; i++){
        fact = fact * i;
            System.out.println(fact);
    }
}
}