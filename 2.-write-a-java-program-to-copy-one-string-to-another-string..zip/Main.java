//2.	Write a java program to copy one string to another string.
import java.util.*;
class Main {
    public static void main(String arg[]){
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        String str1 = str;
        System.out.println(str);
        System.out.println(str1);
    }
}