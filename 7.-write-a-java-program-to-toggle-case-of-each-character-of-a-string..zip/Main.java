//7.	Write a java program to toggle case of each character of a string. 
import java.util.*;
class Main {
    public static void main (String arg[]){
        Scanner sc = new Scanner (System.in);
        String s = sc.next();
        String g ="";
        for (int i = 0; i<s.length(); i++ ){
            if(s.charAt(i) >= 97 &&s.charAt(i) <= 122){
                g=g+(char)(s.charAt(i)-32);
            }
            else{
                g=g+(char)(s.charAt(i)+32);
            }
           
        }
         System.out.println(g);
        
    }
}