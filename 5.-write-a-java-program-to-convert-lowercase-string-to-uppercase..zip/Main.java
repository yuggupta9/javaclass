//5.	Write a java program to convert lowercase string to uppercase.
import java.util.*;
class Main {
    public static void main (String arg[]){
        Scanner sc = new Scanner (System.in);
        String lowerstr = sc.nextLine();
        String upperstr = lowerstr.toUpperCase();
        System.out.println(upperstr);
        
    }
}