//2.    Write a   Java   program to find maximum between three numbers.
import java.util.*;
class Main
{
  public static void main (String arg[])
  {
    Scanner sc = new Scanner (System.in);
      System.out.println ("enter the numbers");
    int num1 = sc.nextInt ();
    int num2 = sc.nextInt ();
    int num3 = sc.nextInt ();
    if (num1 > num2 && num1 > num3)
      {
	System.out.print ("the " + num1 + " is greater");
      }
    else if (num2 > num1 && num2 > num3)
      {
	System.out.print ("the " + num2 + " is greater");
      }
    else
      {
	System.out.print ("the " + num3 + " is greater");
      }
  }
}
