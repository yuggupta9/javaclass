import java.util.*;
class Main{
    public static void main (String[] arg){
    Scanner sc = new Scanner (System.in);
    System.out.println("enter the no.");
    int num1 = sc.nextInt();
    System.out.println("enter the no.");
    int num2 = sc.nextInt();
    System.out.println("the sum is");
    System.out.println( num1 + num2);
    }
}