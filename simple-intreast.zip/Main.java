import java.util.Scanner;
class Main {
    public static void main(String[] arg){
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the p");
        double p = sc.nextDouble();
        System.out.println("enter the r");
        double r = sc.nextDouble();
        System.out.println("enter the t");
        double t = sc.nextDouble();
        System.out.println("simple intreast is");
        System.out.println(p*r*t);
        
    }
}
