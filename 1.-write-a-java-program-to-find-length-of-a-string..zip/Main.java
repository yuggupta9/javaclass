//1.	Write a java program to find length of a string.
import java.util.*;
class Main {
    public static void main(String arg[]){
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        int length = str.length();
        System.out.println(length);
    }
}