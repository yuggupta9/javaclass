//4.    Write a  Javaprogram to check whether a number is divisible by 5 and 11 or not.
import java.util.*;
class Main
{
  public static void main (String arg[])
  {
    Scanner sc = new Scanner (System.in);
      System.out.println ("enter the numbers");
    int num = sc.nextInt ();
    if (num % 5 == 0 && num % 11 == 0)
      {
	System.out.println (num + " is divisible by 5 and 11 or not.");
      }
    else
      {
	System.out.println (num + " is not divisible by 5 and 11 or not.");
      }
  }
}
