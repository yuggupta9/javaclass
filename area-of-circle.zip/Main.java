class Main
{
	public static void main(String[] args) {
	    int r;
	    double area; 
	    r=10;
	    area=3.14*r*r;
		System.out.println(area);
	}
}
