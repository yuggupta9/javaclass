import java.util.*;
class Main{
public static void main (String arg[]){
    Scanner sc = new Scanner(System.in);
    int n = sc.nextInt();
    int sumofdigits= 0;
    while(n>0){
        sumofdigits += n % 10;
        n = n/ 10;
    }
        System.out.println(sumofdigits);
}
}