class Main
{
	public static void main(String[] args) {
	    int l,b,area;
	    l=10;
	    b=20;
	    area=l*b;
		System.out.println(area);
	}
}
