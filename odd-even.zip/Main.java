import java.util.Scanner;
class Main {
    public static void main(String[] arg){
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the no.");
        int num = sc.nextInt();
        if(num % 2 == 0)
        System.out.println("the no. is odd");
        else 
        System.out.println("the no. is even");
    }
}