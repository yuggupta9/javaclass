import java.util.*;
class Main{
public static void main (String arg[]){
    Scanner sc = new Scanner(System.in);
    int n = sc.nextInt();
    int ans = 0 ;
    for (int i = 1 ; i<=n ;i++){
        if (n % 2 == 0 ){
            ans -= n;
        }
        else{
            ans += n;
        }
    }
    System.out.println(ans);
}
}