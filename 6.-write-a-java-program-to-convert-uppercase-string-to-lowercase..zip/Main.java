//6.	Write a java program to convert uppercase string to lowercase.
import java.util.*;
class Main {
    public static void main (String arg[]){
        Scanner sc = new Scanner (System.in);
        String upperstr = sc.nextLine();
        String lowerstr = upperstr.toLowerCase();
        System.out.println(lowerstr);
        
    }
}
